python3 stump_20.py
python3 stump_2000.py
