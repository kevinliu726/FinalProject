python3 hw1_PLA.py
python3 hw1_pocket.py
python3 hw1_pocket2.py
